var mysql = require('mysql');

var con = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  password: "OpLo3647",
  database: 'audiobooks'

});

con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT * FROM audiobooks.catalog", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
  });
});


